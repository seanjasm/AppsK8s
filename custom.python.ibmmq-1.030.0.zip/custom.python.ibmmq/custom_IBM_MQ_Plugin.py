import json
import re
from ruxit.api.base_plugin import BasePlugin
import logging
import socket
from multiprocessing.pool import ThreadPool
import math
import time
import fnmatch
from datetime import datetime
import requests
import getpass
import traceback
from ruxit.api.exceptions import AuthException, ConfigException
from ruxit.api.snapshot import pgi_name
from ruxit.api.data import PluginMeasurement, MEAttribute, PluginProperty
from ruxit.api.selectors import ExplicitSelector, EntityType
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

#logger = logging.getLogger(__name__)
MAX_RESULTS = 1000
MAX_EVENTS = 99

import pymqi
from pymqi.CMQC import *
from pymqi.CMQCFC import *

# custom class to work around the fact that OA extensions ignore self.logger.debug messages.
class Logger():
    def __init__(self, debug: bool, className: str):
        self.debugLevel = debug
        self.logger = logging.getLogger(className)
    def info(self,msg):
        self.logger.info(msg)
    def debug(self,msg):
        if self.debugLevel == True:
            self.logger.info(msg)
    def error(self, msg):
        self.logger.error(msg)
    def warn(self, msg):
        self.logger.warning(msg)
    def exception(self, msg):
        self.logger.exception(msg)
    def critical(self, msg):
        self.critical(msg)
        
class EncodeText(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, (bytes, bytearray)):
            return obj.decode('ASCII')
        # Let the base class default method raise the TypeError
        return json.JSONEncoder.default(self, obj)
        
class CustomIBMMQPlugin(BasePlugin):
    last_topology_retrieve = {}
    # Used for threading
    start = 0
    maxBatchItems = 50
    firstExecution = True
    refreshItemNames = True
    previousEvents = []
    events = 0
    
    qMgrs = {}
    
    OS = {3: 'AIX/Unix', 4: 'IBM i Series', 5: 'Microsoft Windows', 11: 'Microsoft Windows NT', 1: 'z/OS', 13: 'HP Integrity NonStop Server',
         12: 'OpenVMS', 2: 'OS/2', 23: 'z/TPF', 27: 'z/VSE', 28: 'MQ Appliance'}
    
    channel_states = {'INACTIVE': 'Inactive',
                        MQCHS_BINDING: 'Binding',
                        MQCHS_STARTING: 'Starting',
                        MQCHS_RUNNING: 'Running',
                        MQCHS_PAUSED: 'Paused',
                        MQCHS_RETRYING: 'Retrying',
                        MQCHS_STOPPED: 'Stopped',
                        MQCHS_STOPPING: 'Stopping',
                        MQCHS_REQUESTING: 'Requesting',
                        MQCHS_SWITCHING: 'Switching',
                        MQCHS_INITIALIZING: 'Initializing'}                                           
    # Store metrics that need their positive/negative delta calculated
    metricHolder = {}
    channelMetricHolder = {}
    
    timeSinceLastRetrieve = time.time()
    
    pgi_id = None
    
    def error_handler(self, e):
        self.logger.error(traceback.print_exception(type(e), e, e.__traceback__))
    
    def query(self, **kwargs):
        self.logger.info('Polling started')

        self.start = time.time()
    
        # Config GUI vars
        self.config = kwargs['config']
        channels = self.config['channel'].strip()
        listeners = self.config['listener'].strip()
        lastMsgDate, lastMsgTime = None, None
        queues, channels, listeners = {}, {}, {}
        currentQueueDepth, maxQueueDepth = None, None
        self.excludeSystem = True if 'exclude_system' in self.config and str(self.config['exclude_system']).lower() == 'true' else False
        runResetStats = True if 'reset_q_stats' in self.config and str(self.config['reset_q_stats']).lower() == 'true' else False
        proxy_host = self.config.get('http_proxy_host', '').strip()
        proxy_user = self.config.get('http_proxy_user', '').strip()
        proxy_password = self.config.get('http_proxy_password', '')
        self.dlq_alert = True if 'dlq_alert' in self.config and str(self.config['dlq_alert']).lower() == 'true' else False
        self.retry_channel_alert = True if 'retry_channel_alert' in self.config and str(self.config['retry_channel_alert']).lower() == 'true' else False
        self.high_qdepth_alert = True if 'high_qdepth_alert' in self.config and str(self.config['high_qdepth_alert']).lower() == 'true' else False
        self.low_qdepth_alert = True if 'low_qdepth_alert' in self.config and str(self.config['low_qdepth_alert']).lower() == 'true' else False
        debug = True if 'debug' in self.config and str(self.config['debug']).lower() == 'true' else False
        self.user = self.config['username']
        self.password = self.config['password']
        self.request_proxy_list = {}  

        self.logger = Logger(debug, __name__)

        self.logger.debug(f'associated_entity: {kwargs["associated_entity"]}')
        
        # Remove any wildcard from queues and restrict number of queues to MAX_RESULTS
        if 'queues' in self.config and self.config['queues'] != '':
            queues_filter = self.config['queues'].split('\n')
            self.logger.debug(f'queues_filter: {queues_filter}')
            for each_qmgr_in_filter in queues_filter:
                each_qmgr_parts = each_qmgr_in_filter.split(':')
                #self.logger.info(f'each_qmgr_parts: {each_qmgr_parts}')
                if (len(each_qmgr_parts) == 2):
                    each_qmgr = each_qmgr_parts[0]
                
                    queues = each_qmgr_parts[1].split(',',MAX_RESULTS)
                    if len(queues) == MAX_RESULTS+1:
                        queues.pop()
                        
                    #Move queues with wildcards to the end to guarantee specific ones first
                    moveToStart = filter(lambda x: '*' not in x, queues)
                    for item in moveToStart:
                        queues.remove(item)
                        queues.insert(0, item)
                    queues = [x.strip() for x in queues if x is not '']
                    
                    if each_qmgr not in self.qMgrs:
                        self.qMgrs[each_qmgr] = {}
                    self.qMgrs[each_qmgr]['queues'] = queues
                    
                    #self.logger.info(f'qMgrs: {self.qMgrs}')
            
        if 'channel' in self.config and self.config['channel'] != '':
            channels_filter = self.config['channel'].split('\n')
            for each_qmgr_in_filter in channels_filter:
                each_qmgr_parts = each_qmgr_in_filter.split(':')
                if (len(each_qmgr_parts) == 2):
                    each_qmgr = each_qmgr_parts[0]
                    
                    channels = each_qmgr_parts[1].split(',')
                    #Move channels with wildcards to the end to guarantee specific ones first
                    moveToStart = filter(lambda x: '*' not in x, channels)
                    for item in moveToStart:
                        channels.remove(item)
                        channels.insert(0, item)
                    channels = [x.strip() for x in channels if x is not '']
                    
                    if each_qmgr not in self.qMgrs:
                        self.qMgrs[each_qmgr] = {}
                    self.qMgrs[each_qmgr]['channels'] = channels
            
        if 'listener' in self.config and self.config['listener'] != '':
            listener_filter = self.config['listener'].split('\n')
            for each_qmgr_in_filter in listener_filter:
                each_qmgr_parts = each_qmgr_in_filter.split(':')
                if (len(each_qmgr_parts) == 2):
                    each_qmgr = each_qmgr_parts[0]
                    
                    listeners = each_qmgr_parts[1].split(',')
                    listeners = [x.strip() for x in listeners if x is not '']
                    
                    if each_qmgr not in self.qMgrs:
                        self.qMgrs[each_qmgr] = {}
                        
                    self.qMgrs[each_qmgr]['listeners'] = listeners

        pgi_list = self.find_all_process_groups(pgi_name('IBM MQ'))
        for pgi in pgi_list:
            self.logger.debug('pgi object: ' + str(pgi))
            self.pgi_id = pgi.group_instance_id
            for process in pgi.processes:
                if process.process_name.startswith('amqzxma0'):
                    cmd_line = process.properties.get('CmdLine', None)
                    qMgr = cmd_line.split()[1]
                    #self.logger.info(f'qMgr from object: {qMgr}')
                    if qMgr not in self.qMgrs:
                        self.qMgrs[qMgr] = {}
                    self.qMgrs[qMgr]['pgi_id'] = self.pgi_id
                #break
        
        if proxy_host is not '':
            if proxy_user is not '':
                self.request_proxy_list = {'http': f'http://{proxy_user}:{proxy_password}@{proxy_host}/', 'https': f'http://{proxy_user}:{proxy_password}@{proxy_host}/'}
            else:
                self.request_proxy_list = {'http': f'http://{proxy_host}/', 'https': f'http://{proxy_host}/'}
                
        self.logger.info(f'qMgrs to poll: {self.qMgrs}')
        
        self.node = self.results_builder
        
        # Set the commands to run for each entity type
        self.qmgrCommands = ['MQCMD_INQUIRE_Q_MGR_STATUS']
        self.qNameCommands = ['MQCMD_INQUIRE_Q_NAMES']
        self.qCommands = ['MQCMD_INQUIRE_Q', 'MQCMD_INQUIRE_Q_STATUS']
        if runResetStats == True:
            self.qCommands.append('MQCMD_RESET_Q_STATS')
        self.channelCommands = ['MQCMD_INQUIRE_CHANNEL_STATUS']
        self.listenerCommands = ['MQCMD_INQUIRE_LISTENER_STATUS']
        
        self.qmgrMetrics, self.qMetrics, self.cMetrics, self.lMetrics = [], [], [], []
        
        # Set all metrics to retrieve
        self.qmgrMetrics.append({'name': 'QueueManager.Status', 'command': 'MQCMD_INQUIRE_Q_MGR_STATUS', 'attr': MQIACF_Q_MGR_STATUS, 'owner': 'QueueManager', 'metric': 'absolute', 'normalValue' : MQQMSTA_RUNNING})
        self.qmgrMetrics.append({'name': 'QueueManager.Connections', 'command': 'MQCMD_INQUIRE_Q_MGR_STATUS', 'attr': MQIACF_CONNECTION_COUNT, 'owner': 'QueueManager', 'metric': 'absolute'})
        
        self.qMetrics.append({'name': 'Queue.Depth', 'command': 'MQCMD_INQUIRE_Q', 'attr': MQIA_CURRENT_Q_DEPTH, 'owner': 'Queue', 'metric': 'absolute', 'splitName': 'Queue', 'splitBy': MQCA_Q_NAME})
        self.qMetrics.append({'name': 'Queue.InhibitGet', 'command': 'MQCMD_INQUIRE_Q', 'attr': MQIA_INHIBIT_GET, 'owner': 'Queue', 'metric': 'absolute', 'splitName': 'Queue', 'splitBy': MQCA_Q_NAME, 'normalValue' : 'MQQA_GET_ALLOWED'})
        self.qMetrics.append({'name': 'Queue.InhibitPut', 'command': 'MQCMD_INQUIRE_Q', 'attr': MQIA_INHIBIT_PUT, 'owner': 'Queue', 'metric': 'absolute', 'splitName': 'Queue', 'splitBy': MQCA_Q_NAME, 'normalValue' : 'MQQA_PUT_ALLOWED'})
        self.qMetrics.append({'name': 'Queue.MaxQueueDepth', 'command': 'MQCMD_INQUIRE_Q', 'attr': MQIA_MAX_Q_DEPTH, 'owner': 'Queue', 'metric': 'absolute', 'splitName': 'Queue', 'splitBy': MQCA_Q_NAME})
        self.qMetrics.append({'name': 'Queue.OpenInputCount', 'command': 'MQCMD_INQUIRE_Q', 'attr': MQIA_OPEN_INPUT_COUNT, 'owner': 'Queue', 'metric': 'absolute', 'splitName': 'Queue', 'splitBy': MQCA_Q_NAME})
        self.qMetrics.append({'name': 'Queue.OpenOutputCount', 'command': 'MQCMD_INQUIRE_Q', 'attr': MQIA_OPEN_OUTPUT_COUNT, 'owner': 'Queue', 'metric': 'absolute', 'splitName': 'Queue', 'splitBy': MQCA_Q_NAME})
        self.qMetrics.append({'name': 'Queue.OldestMessageAge', 'command': 'MQCMD_INQUIRE_Q_STATUS', 'attr': MQIACF_OLDEST_MSG_AGE, 'owner': 'Queue', 'metric': 'absolute', 'unavailable': MQMON_NOT_AVAILABLE, 'splitName': 'Queue', 'splitBy': MQCA_Q_NAME})
        self.qMetrics.append({'name': 'Queue.UncommittedMessages', 'command': 'MQCMD_INQUIRE_Q_STATUS', 'attr': MQIACF_UNCOMMITTED_MSGS, 'owner': 'Queue', 'metric': 'absolute', 'splitName': 'Queue', 'splitBy': MQCA_Q_NAME})
        self.qMetrics.append({'name': 'Queue.LastGetDate', 'command': 'MQCMD_INQUIRE_Q_STATUS', 'attr': MQCACF_LAST_GET_DATE, 'owner': 'Queue', 'metric': 'absolute', 'splitName': 'Queue', 'splitBy': MQCA_Q_NAME})
        self.qMetrics.append({'name': 'Queue.LastGetTime', 'command': 'MQCMD_INQUIRE_Q_STATUS', 'attr': MQCACF_LAST_GET_TIME, 'owner': 'Queue', 'metric': 'absolute', 'splitName': 'Queue', 'splitBy': MQCA_Q_NAME})
        self.qMetrics.append({'name': 'Queue.LastPutDate', 'command': 'MQCMD_INQUIRE_Q_STATUS', 'attr': MQCACF_LAST_PUT_DATE, 'owner': 'Queue', 'metric': 'absolute', 'splitName': 'Queue', 'splitBy': MQCA_Q_NAME})
        self.qMetrics.append({'name': 'Queue.LastPutTime', 'command': 'MQCMD_INQUIRE_Q_STATUS', 'attr': MQCACF_LAST_PUT_TIME, 'owner': 'Queue', 'metric': 'absolute', 'splitName': 'Queue', 'splitBy': MQCA_Q_NAME})
        if runResetStats == True:
            self.qMetrics.append({'name': 'Queue.DequeueRate', 'command': 'MQCMD_RESET_Q_STATS', 'attr': MQIA_MSG_DEQ_COUNT, 'owner': 'Queue', 'metric': 'absolute', 'splitName': 'Queue', 'splitBy': MQCA_Q_NAME})
            self.qMetrics.append({'name': 'Queue.EnqueueRate', 'command': 'MQCMD_RESET_Q_STATS', 'attr': MQIA_MSG_ENQ_COUNT, 'owner': 'Queue', 'metric': 'absolute', 'splitName': 'Queue', 'splitBy': MQCA_Q_NAME})
        self.qMetrics.append({'name': 'Queue.TimeIndicator', 'command': 'MQCMD_INQUIRE_Q_STATUS', 'attr': MQIACF_Q_TIME_INDICATOR, 'owner': 'Queue', 'metric': 'absolute', 'unavailable': MQMON_NOT_AVAILABLE, 'splitName': 'Queue', 'splitBy': MQCA_Q_NAME})
        
        self.cMetrics.append({'name': 'Channel.Status2', 'command': 'MQCMD_INQUIRE_CHANNEL_STATUS', 'attr': MQIACH_CHANNEL_STATUS, 'owner': 'Channel', 'metric': 'absolute', 'splitName': 'Channel', 'splitBy': MQCACH_CHANNEL_NAME})
        self.cMetrics.append({'name': 'Channel.Messages', 'command': 'MQCMD_INQUIRE_CHANNEL_STATUS', 'attr': MQIACH_MSGS, 'owner': 'Channel', 'metric': 'absolute', 'splitName': 'Channel', 'splitBy': MQCACH_CHANNEL_NAME, 'aggregationField': MQIACH_MSGS})
        self.cMetrics.append({'name': 'Channel.BytesSent', 'command': 'MQCMD_INQUIRE_CHANNEL_STATUS', 'attr': MQIACH_BYTES_SENT, 'owner': 'Channel', 'metric': 'absolute', 'splitName': 'Channel', 'splitBy': MQCACH_CHANNEL_NAME, 'aggregationField': MQIACH_BYTES_SENT})
        self.cMetrics.append({'name': 'Channel.BytesReceived', 'command': 'MQCMD_INQUIRE_CHANNEL_STATUS', 'attr': MQIACH_BYTES_RECEIVED, 'owner': 'Channel', 'metric': 'absolute', 'splitName': 'Channel', 'splitBy': MQCACH_CHANNEL_NAME, 'aggregationField': MQIACH_BYTES_RECEIVED})
        self.cMetrics.append({'name': 'Channel.BuffersSent', 'command': 'MQCMD_INQUIRE_CHANNEL_STATUS', 'attr': MQIACH_BUFFERS_SENT, 'owner': 'Channel', 'metric': 'absolute', 'splitName': 'Channel', 'splitBy': MQCACH_CHANNEL_NAME, 'aggregationField': MQIACH_BUFFERS_SENT})
        self.cMetrics.append({'name': 'Channel.BuffersReceived', 'command': 'MQCMD_INQUIRE_CHANNEL_STATUS', 'attr': MQIACH_BUFFERS_RECEIVED, 'owner': 'Channel', 'metric': 'absolute', 'splitName': 'Channel', 'splitBy': MQCACH_CHANNEL_NAME, 'aggregationField': MQIACH_BUFFERS_RECEIVED})
        self.cMetrics.append({'name': 'Channel.LastMsgDate', 'command': 'MQCMD_INQUIRE_CHANNEL_STATUS', 'attr': MQCACH_LAST_MSG_DATE, 'owner': 'Channel', 'metric': 'absolute', 'splitName': 'Channel', 'splitBy': MQCACH_CHANNEL_NAME})
        self.cMetrics.append({'name': 'Channel.LastMsgTime', 'command': 'MQCMD_INQUIRE_CHANNEL_STATUS', 'attr': MQCACH_LAST_MSG_TIME, 'owner': 'Channel', 'metric': 'absolute', 'splitName': 'Channel', 'splitBy': MQCACH_CHANNEL_NAME})
        self.cMetrics.append({'name': 'Channel.CurrentSharingConvs', 'command': 'MQCMD_INQUIRE_CHANNEL_STATUS', 'attr': MQIACH_CURRENT_SHARING_CONVS, 'owner': 'Channel', 'metric': 'absolute', 'splitName': 'Channel', 'splitBy': MQCACH_CHANNEL_NAME, 'aggregationField': MQIACH_CURRENT_SHARING_CONVS})
        
        self.lMetrics.append({'name': 'Channel.ListenerStatus', 'command': 'MQCMD_INQUIRE_LISTENER_STATUS', 'attr': MQIACH_LISTENER_STATUS, 'owner': 'ChannelListener', 'metric': 'absolute', 'splitName': 'Listener', 'splitBy': MQCACH_LISTENER_NAME, 'normalValue': MQSVC_STATUS_RUNNING})
        
        qmgr = None
        pool_size = len([x for x in self.qMgrs if 'pgi_id' in self.qMgrs[x]])
        
        self.logger.info(f'Pool size = {pool_size}')
        # Run queue threads
        if pool_size > 0:
            pool = ThreadPool(processes=pool_size)
            for queueManager in self.qMgrs:
                if 'pgi_id' in self.qMgrs[queueManager]:
                    self.qMgrs[queueManager]['name'] = queueManager
                    pool.apply_async(self.run_mq_data_collection, (self.qMgrs[queueManager],), error_callback=self.error_handler)
                    
                    #result.get()
                else:
                    self.logger.warn(f'Process for queue manager {queueManager} not found.')
                    
            pool.close()
            
            # Max polling time is 50 seconds
            process_alive = False
            while time.time() - self.start < 50:
                process_alive = False
                for process in pool._pool:
                    if process.is_alive():
                        process_alive = True
               
                if not process_alive:
                    self.logger.info('All processes finished, exiting checking loop')
                    break
                    
                self.logger.info(f'Sleeping for a second... process is still alive')
                time.sleep(1)
            
            # If we get to this point, a process was flagged alive and it's been more than 50 seconds, then terminate it
            # Otherwise, if process_alive was not set above, then no process should be alive at this point and no need to terminate
            if process_alive:
                pool.terminate()
                pool.join()
                self.logger.info('Some processes are alive. Terminating before finishing polling cycle')
            
        # If it's been over an hour since last retrieval or failed or skipped entities, reset to retry them
        now = time.time()
        if now - self.timeSinceLastRetrieve > 3600:
            self.refreshItemNames = True
            self.timeSinceLastRetrieve = now
            self.qMgrs.clear()
        else:
            self.refreshItemNames = False
            
        # After executing once
        self.firstExecution = False      
        
        self.logger.info(f'Finished executing plugin.')

    def run_mq_data_collection(self, qMgr):
        self.logger.info(f"Running async thread for queue manager {qMgr['name']}")
        pgi_id = qMgr['pgi_id']
        pgi = ExplicitSelector(qMgr['pgi_id'], EntityType.PROCESS_GROUP_INSTANCE)
        queues = qMgr['queues'] if 'queues' in qMgr else None
        channels = qMgr['channels'] if 'channels' in qMgr else None
        listeners = qMgr['listeners'] if 'listeners' in qMgr else None
        if 'qItems' not in qMgr:
            qMgr['qItems'] = []
        if 'cItems' not in qMgr:
            qMgr['cItems'] = []
        pcf = None
        qmgr = pymqi.QueueManager(None)
        
        qmgr_name = qMgr['name']
        try:
            qmgr = self.makeConnection(qmgr_name)
            pcf = pymqi.PCFExecute(qmgr)
        except pymqi.MQMIError as e:
            if e.comp == MQCC_FAILED:
                if qmgr.is_connected:
                    qmgr.disconnect()
                
                if e.reason == MQRC_NOT_AUTHORIZED:
                    self.node.report_error_event(f'Connection failed. Unauthorized user. {e.errorAsString()}', 'Unauthorized user')
                    raise AuthException(f'Connection failed. Unauthorized user {self.config["username"]}. {e.errorAsString()}')
                elif e.reason == MQRC_Q_MGR_NAME_ERROR:
                    self.node.report_error_event(f'Connection failed. Queue manager error: {qmgr_name}', 'Queue manager error')
                    raise ConfigException(f'Connection failed. Queue manager not found: {qmgr_name}. {e.errorAsString()}')
                else:
                    self.setMetric(qmgr_name, 'absolute', 'QueueManager.Status', 0, {}, pgi)
                    if self.firstExecution:
                        raise ConfigException(f'Could not connect to local Queue Manager: {qmgr_name}. {e.errorAsString()}')
                    self.logger.error(f'Connection to {qmgr_name} failed: Setting availability to 0%. {e.errorAsString()}')
                return
            else:
                if e.reason == MQRC_SELECTOR_NOT_FOR_TYPE:
                    self.logger.warn(f'Attempting to collect data for a queue type not supported. {e.errorAsString()}')
                else:
                    self.logger.warn(f'An issue occurred connecting to {conn_info}. {e.errorAsString()}. Continuing')
        except Exception as e:
            self.logger.error(f'An unknown error occurred. {e}')

        #self.logger.info(f'pcf = {type(pcf)}. qmgr = {qmgr}. Connected = {qmgr.is_connected}')
        if isinstance(pcf, pymqi.PCFExecute) and qmgr and qmgr.is_connected:
            if qmgr_name not in self.last_topology_retrieve:
                self.last_topology_retrieve[qmgr_name] = {'time': 0}
                
            try:
                # Query for topology
                if self.config['get_queue_topology'] and (self.firstExecution or time.time()-self.last_topology_retrieve[qmgr_name]['time'] > 3600):
                    topology_data = self.build_topology(pcf, qmgr, qmgr_name, pgi)
                    
                    if topology_data:
                        result = self.send_topology(topology_data, self.config['api_token'], self.config['api_endpoint'], qmgr_name, pgi)
            except pymqi.MQMIError as e:
                self.logger.exception(f'Could not query queue manager {qmgr_name} topology. Reason: {e.errorAsString()}')
                self.report_custom_info_event(f'Could not query queue manager {qmgr_name} topology. Reason: {e.errorAsString()}', 'Could not query queue manager', {}, entity_selector=pgi)
                                        
            self.logger.info(f'Connected to {qmgr_name}')
            # Let's start by pinging the Queue Manager. If anything but an empty response, then it's unresponsive and no point continuing
            pingResponse = False
            try:
                pcf.MQCMD_PING_Q_MGR()
            except pymqi.MQMIError as e:
                # Not necessarily unresponsive. 
                if e.comp == MQCC_WARNING and e.reason == MQRC_SELECTOR_NOT_FOR_TYPE:
                    self.logger.warn('PING_Q_MGR command not supported on this platform, stopping...')
                    raise ConfigException(f'Could not run ping command to {qmgr_name} due to unsupported OS. Supported platforms are Windows/Linux')
                    return
                else: 
                    self.report_custom_info_event(f'Ping to queue manager {qmgr_name} failed. Queue manager may be unresponsive.', f'Ping to {qmgr_name} failed', {}, pgi)
                    self.logger.warn('Ping command failed. Attemping to continue polling data.')

            qResponse, cResponse, lResponse = {}, {}, {}
            totalActiveChannels = None
            
        
            qmgrResponse = {}
            
            try:
                #self.logger.info(f'Inquiring Version from Q_MGR {qmgr_name}')
                qmgrVersionRes = getattr(pcf, 'MQCMD_INQUIRE_Q_MGR')({MQIACF_Q_MGR_ATTRS: MQCA_VERSION})[0]
                version = qmgrVersionRes[MQCA_VERSION].strip()
                version = f'{int(version[0:2])}.{int(version[2:4])}'
            except pymqi.MQMIError as e:
                self.logger.warn(f'Could not get version. {e.errorAsString()}')
                version = 'Unknown version'
                
            try:
                #self.logger.info('Inquiring platform from Q_MGR '+qmgr_name)
                platform = qmgr.inquire(MQIA_PLATFORM)
                if platform not in [3,5,11,28]:
                    if platform not in self.OS:
                        self.OS[platform] = f'Unknown[{platform}]'
                    raise ConfigException(f'Unsupported MQ platform: {self.OS[platform]}. Supported platforms are Windows/Linux')
                    return
                    
                maxPriority = qmgr.inquire(MQIA_MAX_PRIORITY)
                
                if platform in self.OS:
                    OSname = f'IBM MQ {version} on {self.OS[platform]}'
                else:
                    OSname = f'Unknown[{platform}]'
                
                self.add_property('Queue manager', qmgr_name, pgi)
                self.add_property('Version', OSname, pgi)
                
                self.logger.info(f"{qmgr_name} MQ Version: {OSname}")
                
                #self.logger.info('Running Q_MGR commands')
                for command in self.qmgrCommands:
                    # Run command with its arguments
                    qmgrResponse = getattr(pcf, command)()[0]
                    #self.logger.info(qmgrResponse)
                
                if self.dlq_alert:         
                    # Get the Dead Letter queue name
                    # Report a problem if DLQ has messages. These are undeliverable messages.
                    #self.logger.info(f'Inquiring Q_MGR {qmgr_name} for DLQ')
                    deadLetterQName = str(qmgr.inquire(MQCA_DEAD_LETTER_Q_NAME), 'utf-8', 'ignore').strip()
                    deadLetterQDepth = None                            
                    try:
                        if deadLetterQName != '':
                            #self.logger.info(f'DLQ is {deadLetterQName}')
                            deadLetterQ = pymqi.Queue(qmgr, deadLetterQName)
                            deadLetterQDepth = deadLetterQ.inquire(MQIA_CURRENT_Q_DEPTH)
                            if deadLetterQDepth > 0:
                                self.node.report_error_event(f'Dead letter queue {deadLetterQName} on {qmgr_name} has {deadLetterQDepth} undeliverable message(s)', f'DLQ {deadLetterQName} on {qmgr_name} has message(s)', entity_selector=pgi)
                    except pymqi.MQMIError as e2:
                        self.report_custom_info_event(f'Could not collect data from Dead letter queue {deadLetterQName} on {qmgr_name}. {e2.errorAsString()}', 'Error collecting from DLQ', {}, pgi)
                        self.logger.warn(f'WARNING: Attempted to get data from DLQ {deadLetterQName} but failed. {e2.errorAsString()}')
                    finally:        
                        if deadLetterQDepth:               
                            deadLetterQ.close()        
                
                try:
                    # Get a count of active channels
                    #self.logger.info(f'Inquiring Q_MGR {qmgr_name} for total current active channels')
                    args = {MQCACH_CHANNEL_NAME: pymqi.ensure_bytes('*'), MQIACH_CHANNEL_INSTANCE_ATTRS: MQCACH_CHANNEL_NAME, MQIACH_CHANNEL_INSTANCE_TYPE: MQOT_CURRENT_CHANNEL}
                    currentChannelsResponse = getattr(pcf, 'MQCMD_INQUIRE_CHANNEL_STATUS')(args)
                    totalActiveChannels = len(currentChannelsResponse)
                except pymqi.MQMIError as e2:
                    self.logger.warn(f'No active channels on {OSname} for {qmgr_name}... Continuing. {e2.errorAsString()}')
                    totalActiveChannels = 0
                    
                # Get queue names and count first so we can multi-thread them. If we don't, we may get too many results and plugin may time out
                if self.refreshItemNames:
                    #self.logger.info(f'Inquire Q_MGR {qmgr_name} for Q names and Channel names')
                    if 'queues' in qMgr:
                        qMgr['qItems'] = self.getItemNames(pcf, qmgr_name, queues, 'MQCMD_INQUIRE_Q_NAMES', MQCA_Q_NAME, MQCACF_Q_NAMES, self.excludeSystem, pgi)
                        self.logger.info(f'qItems: {qMgr["qItems"]}')
                    if 'channels' in qMgr:
                        qMgr['cItems'] = self.getItemNames(pcf, qmgr_name, channels, 'MQCMD_INQUIRE_CHANNEL_NAMES', MQCACH_CHANNEL_NAME, MQCACH_CHANNEL_NAMES, self.excludeSystem, pgi)
                        self.logger.info(f'cItems: {qMgr["cItems"]}')
                    
                # Query MQ for listener status
                if 'listeners' in qMgr:
                    #self.logger.info(f'Inquiring {qmgr_name} Listener for with commands: {self.listenerCommands}')
                    self.getMetricsForEntity(pcf, qmgr_name, listeners, self.listenerCommands, MQCACH_LISTENER_NAME, lResponse, pgi)
                    
                self.getMetricsForEntity(pcf, qmgr_name, qMgr['qItems'], self.qCommands, MQCA_Q_NAME, qResponse, pgi)
                self.getMetricsForEntity(pcf, qmgr_name, qMgr['cItems'], self.channelCommands, MQCACH_CHANNEL_NAME, cResponse, pgi)
                
            except pymqi.MQMIError as e:
                if e.comp == MQCC_WARNING and e.reason == MQRC_SELECTOR_NOT_FOR_TYPE:
                    self.logger.warn('Could not run some commands on this OS, perhaps it is not supported. Continuing...')
                else:
                    self.logger.exception(f'Could not query queue manager. Reason: {e.errorAsString()}')
                    self.report_custom_info_event(f'Could not query queue manager {qmgr_name}. Reason: {e.errorAsString()}', 'Could not query queue manager', {}, pgi)
            finally:
                if qmgr.is_connected:
                    qmgr.disconnect()

            
            # Loop through Queue Manager metrics result
            self.logger.info(f'Reporting metrics for Queue Manager. QM Metrics: {len(qmgrResponse)}')
            for metric in self.qmgrMetrics:
                fieldId = metric['attr']
                metricDimension = {}
                if metric['owner'] == 'QueueManager':
                    if fieldId in qmgrResponse:
                        self.logger.debug(f'qMgr: {metric["attr"]}: {qmgrResponse[fieldId]}')
                        val = qmgrResponse[fieldId]
                        if 'normalValue' in metric:
                            val = 100 if val == metric['normalValue'] else 0
                        self.setMetric(qmgr_name, metric['metric'], metric['name'], val, {}, pgi)
            if totalActiveChannels:
                self.setMetric(qmgr_name, 'absolute', 'QueueManager.ActiveChannels', totalActiveChannels, {}, pgi)

            # Loop through all Queue metrics results
            self.logger.info(f'Reporting metrics for Queues. Queue Metrics: {len(qResponse)}')
            for queue in qResponse:
                metricDimension = {}
                metricDimension['Queue'] = queue
                maxQueueDepth, currentQueueDepth, lastGetDate, lastGetTime, lastPutDate, lastPutTime = None,None,None,None,None,None
                
                for command in qResponse[queue]:
                    for metric in self.qMetrics:
                        fieldId = metric['attr']
                        if command == metric['command']:
                            if fieldId in qResponse[queue][command]:
                                if metric['attr'] == MQIACF_Q_TIME_INDICATOR:
                                    if len(qResponse[queue][command][fieldId]) > 0:
                                        qTimeShort = qResponse[queue][command][fieldId][0]
                                        qTimeLong = qResponse[queue][command][fieldId][1]
                                        if qTimeShort != MQMON_NOT_AVAILABLE and qTimeLong != MQMON_NOT_AVAILABLE:
                                            self.setMetric(qmgr_name, metric['metric'], metric['name']+'Short', qTimeShort, metricDimension, pgi)
                                            self.setMetric(qmgr_name, metric['metric'], metric['name']+'Long', qTimeLong, metricDimension, pgi)
                                elif metric['attr'] == MQCACF_LAST_GET_DATE:
                                    if len(qResponse[queue][command][fieldId]) > 0:
                                        lastGetDate = datetime.strptime(qResponse[queue][command][fieldId], '%Y-%m-%d')
                                elif metric['attr'] == MQCACF_LAST_GET_TIME:
                                    if len(qResponse[queue][command][fieldId]) > 0:
                                        lastGetTime = datetime.strptime(qResponse[queue][command][fieldId], '%H.%M.%S')
                                elif metric['attr'] == MQCACF_LAST_PUT_DATE:
                                    if len(qResponse[queue][command][fieldId]) > 0:
                                        lastPutDate = datetime.strptime(qResponse[queue][command][fieldId], '%Y-%m-%d')
                                elif metric['attr'] == MQCACF_LAST_PUT_TIME:
                                    if len(qResponse[queue][command][fieldId]) > 0:
                                        lastPutTime = datetime.strptime(qResponse[queue][command][fieldId], '%H.%M.%S')
                                elif metric['attr'] == MQIA_MSG_DEQ_COUNT or metric['attr'] == MQIA_MSG_ENQ_COUNT:
                                    if MQIA_TIME_SINCE_RESET in qResponse[queue][command]:
                                        if qResponse[queue][command][MQIA_TIME_SINCE_RESET] == 0:
                                            qResponse[queue][command][MQIA_TIME_SINCE_RESET] = 1
                                        self.setMetric(qmgr_name, metric['metric'], metric['name'], int(qResponse[queue][command][fieldId])/float(qResponse[queue][command][MQIA_TIME_SINCE_RESET]), metricDimension, pgi)
                                else:
                                    if metric['attr'] == MQIA_MAX_Q_DEPTH:
                                        maxQueueDepth = qResponse[queue][command][fieldId]
                                    if metric['attr'] == MQIA_CURRENT_Q_DEPTH:
                                        currentQueueDepth = qResponse[queue][command][fieldId]
                                    if metric['attr'] != MQIA_MAX_Q_DEPTH and qResponse[queue][command][fieldId] != MQMON_NOT_AVAILABLE:
                                        self.setMetric(qmgr_name, metric['metric'], metric['name'], qResponse[queue][command][fieldId], metricDimension, pgi)

                            else:
                                self.logger.debug(f'Field id: {fieldId} not found in qResponse')
                if maxQueueDepth and currentQueueDepth is not None:
                    queuePercentQueueDepth = (currentQueueDepth * 100) / maxQueueDepth if maxQueueDepth > 0 else 0
                    self.setMetric(qmgr_name, metric['metric'], 'Queue.PercentQueueDepth', queuePercentQueueDepth, metricDimension, pgi)
                
                if lastGetDate and lastGetTime:
                    lastGetDateTimeDelta = datetime.now()-datetime.combine(lastGetDate.date(), lastGetTime.time())
                    #self.logger.info(f'lastGetDateTimeDelta: {lastGetDateTimeDelta}')
                    lastGetDateTime = (lastGetDateTimeDelta.seconds*1000)+(lastGetDateTimeDelta.microseconds/1000)
                    self.setMetric(qmgr_name, 'absolute', 'Queue.LastGet', lastGetDateTime, metricDimension, pgi)
                
                if lastPutDate and lastPutTime:
                    lastPutDateTimeDelta = datetime.now()-datetime.combine(lastPutDate.date(), lastPutTime.time())
                    #self.logger.info(f'lastPutDateTimeDelta: {lastPutDateTimeDelta}')
                    lastPutDateTime = (lastPutDateTimeDelta.seconds*1000)+(lastPutDateTimeDelta.microseconds/1000)
                    self.setMetric(qmgr_name, 'absolute', 'Queue.LastPut', lastPutDateTime, metricDimension, pgi)
                    
                # Check auto-alerts
                high_qdepth_limit = int(qResponse[queue]['MQCMD_INQUIRE_Q'][MQIA_Q_DEPTH_HIGH_LIMIT])
                low_qdepth_limit = int(qResponse[queue]['MQCMD_INQUIRE_Q'][MQIA_Q_DEPTH_LOW_LIMIT])
                if self.high_qdepth_alert and currentQueueDepth >= high_qdepth_limit:
                    # Send alert
                    self.node.report_resource_contention_event(f"Queue {queue} on {qmgr_name} has a higher queue depth than configured High queue depth limit threshold. Current queue depth = {currentQueueDepth}. High depth limit = {high_qdepth_limit}", f"Queue depth too high", {"Queue manager": qmgr_name, "Queue": queue}, entity_selector=pgi)
                    #logger.debug('Sent high limit event')
                if self.low_qdepth_alert and currentQueueDepth < low_qdepth_limit:
                    # Send alert
                    self.node.report_resource_contention_event(f"Queue {queue} on {qmgr_name} has a lower queue depth than configured Low queue depth limit threshold. Current queue depth = {currentQueueDepth}. Low depth limit = {low_qdepth_limit}", f"Queue depth too low", {"Queue manager": qmgr_name, "Queue": queue}, entity_selector=pgi)
                    #logger.debug('Sent low limit event')

            # Loop through all Channel metrics results
            self.logger.info(f'Reporting metrics for channels. Channel Metrics: {len(cResponse)}')
            for channel in cResponse:
                metricDimension = {}
                for metric in self.cMetrics:
                    metricDimension[metric['splitName']] = channel
                    fieldId = metric['attr']
                    for command in cResponse[channel]:
                        if command == metric['command']:
                            if fieldId in cResponse[channel][command] and str(cResponse[channel][command][fieldId]).strip() != '':
                                val = cResponse[channel][command][fieldId]
                                if fieldId == MQIACH_CHANNEL_STATUS:
                                    if val == MQCHS_RETRYING and self.retry_channel_alert:
                                        self.node.report_error_event(f'Channel {channel} on {qmgr_name} is in Retrying state', f'Channel {channel} in Retrying state', properties={'Queue manager': qmgr_name, 'Channel': channel}, entity_selector=pgi)
                                    self.logger.debug(f'Setting channel status to: {val} = {self.channel_states[val]}')
                                    self.results_builder.state_metric('Channel.Status2', self.channel_states[val], metricDimension, entity_selector=pgi)
                                    continue    
                                if 'normalValue' in metric:
                                    val = 100 if val == metric['normalValue'] else 0
                                elif 'aggregationField' in metric:
                                    if metric['aggregationField'] in cResponse[channel]:
                                        #self.logger.info(f'Aggregation field in cResponse for {metricDimension}')
                                        # Use this value and set it now. Otherwise value in body of response will be used which is not correct one
                                        val = cResponse[channel][metric['aggregationField']]
                                        self.setMetric(qmgr_name, metric['metric'], metric['name'], val, metricDimension, pgi)
                                    continue
                                if fieldId == MQCACH_LAST_MSG_DATE:
                                    df = '%Y-%m-%d'
                                    lastMsgDate = datetime.strptime(val, df)
                                elif fieldId == MQCACH_LAST_MSG_TIME:
                                    tf = '%H.%M.%S'
                                    lastMsgTime = datetime.strptime(val, tf)
                                else:
                                    self.setMetric(qmgr_name, metric['metric'], metric['name'], val, metricDimension, pgi)

                # Last messages needs to be converted to seconds as it is an array object of dates
                if 'lastMsg' in cResponse[channel]:
                    lastMsgDateTime = (datetime.now()-cResponse[channel]['lastMsg']).total_seconds()
                    self.setMetric(qmgr_name, 'absolute', 'Channel.LastMsg', lastMsgDateTime, metricDimension, pgi)

            # Loop through all Listener metrics
            self.logger.info(f'Reporting metrics for Listeners. Listener Metrics: {len(lResponse)}')
            for listener in lResponse:
                metricDimension = {}
                for metric in self.lMetrics:
                    metricDimension[metric['splitName']] = listener
                    fieldId = metric['attr']
                    for command in lResponse[listener]:
                        if command == metric['command']:
                            if fieldId in lResponse[listener][command]:
                                val = lResponse[listener][command][fieldId]
                                if 'normalValue' in metric:
                                    val = 100 if val == metric['normalValue'] else 0
                                self.setMetric(qmgr_name, metric['metric'], metric['name'], val, metricDimension, pgi)
                        
        else:
            self.logger.warn(f'Not able to get pcf connection object. Check IBM MQ can receive connections and process PCF commands. Finishing...')
            
        if qmgr:
            if qmgr.is_connected:
                qmgr.disconnect()
                qmgr = None

    
    # Get list of item names first to get an idea how many will be returned when we actually get data
    def getItemNames(self, pcf, qmgr_name, entities, command, identifier, returnedIdentifier, excludeSystem, pgi):
        if not entities:
            return []
            
        items = []
        searchingQueues = False
        ran_once = False
        if '*' in entities: # Only remove noise when searching for all
            entities += ['-MQAI.REPLY.*', '-AMQ.*', '-PYMQPCF*']
        entities = list(set(entities))
        entities = sorted(entities)
        for entity in entities:
            if '*' not in entity:
                if entity.startswith('-') or entity.startswith('~'):
                    items.append(entity[1:])
                else:
                    items.append(entity)
                continue
            else:
                if not ran_once: # Only search for * once
                    args = {identifier : pymqi.ensure_bytes('*')}
                    self.logger.debug(f'Searching for: * using command {command} then filtering after')
                    try:
                        fullResponse = getattr(pcf, command)(args)
                        self.logger.debug(f'FullResponse: {fullResponse} from command {command}')
                        for eachEntity in fullResponse:
                            if returnedIdentifier in eachEntity: # Make sure it's not an empty result
                                itemNames = eachEntity[returnedIdentifier]
                                if (MQIACF_Q_TYPES in eachEntity):
                                    searchingQueues = True
                                self.logger.debug(f'Total items: {len(itemNames)}')
                                
                                # Add only items that are not in list
                                if isinstance(itemNames, list):
                                    for index, name in enumerate(itemNames):
                                        name = str(name,'utf-8', 'ignore').strip()
                                        if (searchingQueues and name not in items and eachEntity[MQIACF_Q_TYPES][index] == MQQT_LOCAL) or (not searchingQueues and name not in items):
                                            items.append(name)
                                else:
                                    itemNames = str(itemNames,'utf-8', 'ignore').strip()
                                    if (searchingQueues and itemNames not in items and eachEntity[MQIACF_Q_TYPES] == MQQT_LOCAL) or (not searchingQueues and itemNames not in items):
                                        items.append(itemNames)
                            
                    except pymqi.MQMIError as e:
                        if e.comp == MQCC_FAILED and e.reason == MQRC_UNKNOWN_OBJECT_NAME:
                            self.report_custom_info_event(f'Error collecting information for {entity} on {qmgr_name}. Not found or wrong type. {e.errorAsString()}', f'{entity} on {qmgr_name}. Not found or wrong type', {}, pgi)
                            self.logger.error(f'Error collecting information for {entity} on {qmgr_name}. {e.errorAsString()}')
                            #raise ConfigException('Error collecting information for ' + entity + '. Not found or wrong type')
                        else:
                            self.logger.error(f'Error searching for {entity} on {qmgr_name}. {e.errorAsString()}')
                        continue
                    ran_once = True
        
        #self.logger.debug(f'Full raw list of items before filter: {items}')
        
        # Filter out any SYSTEM items if selected
        if excludeSystem == True:
            entities.append('-SYSTEM.*')

        final_items = []
        for entity in entities:
            if entity == '*':
                final_items = items
            else:
                if entity.startswith('-') or entity.startswith('~'):
                    final_items = [item for item in final_items if not fnmatch.fnmatch(item, entity[1:])]
                else:
                    final_items += [item for item in items if fnmatch.fnmatch(item, entity)]

        # Make them unique
        final_items = list(set(final_items))
        items.clear()

        return final_items[0:MAX_RESULTS]
                                        
    def filterItems(self, items, patterns, exclude):
        if exclude:
            for item in items:
                if any(fnmatch.fnmatch(item, pattern) for pattern in patterns):
                    yield item
        else:
            for item in items:
                if any(fnmatch.fnmatch(item, pattern) for pattern in patterns):
                    yield item
                
    # Collect metrics for each entity and command
    def getMetricsForEntity(self, pcf, qmgr_name, entities, commands, identifier, metricResponse, pgi):
        args = {}
        currentIteration = 0
        for entity in entities:
            qType = {}
            for command in commands:
                self.logger.debug(f'Doing command {command} for entity {entity}')
                timerStart = time.time()
                if (identifier):
                    #self.logger.info(f'Identifier: {identifier}')
                    args = {identifier : pymqi.ensure_bytes(entity)}
                try:
                    fullResponse = getattr(pcf, command)(args)
                    self.logger.debug(f'FullResponse for command {command}: {fullResponse}')
                    #self.logger.info(f'Received response from MQ. Command: {command}. Entity: {entity}. Took {time.time()-timerStart} seconds')

                    for i, eachEntity in enumerate(fullResponse):
                        #Clean each key-value pair. Data from MQ comes with extra spaces
                        eachEntity = { k:str(v,'utf-8', 'ignore').replace('\x00','').strip() if isinstance(v, bytes) else v for k,v in eachEntity.items() }
                        #eachEntity = { k:v.strip() if isinstance(v, str) else v for k,v in eachEntity.items() }
                        entityName = eachEntity[identifier]
                        if entityName not in metricResponse:
                            metricResponse[entityName] = {}
                        
                        metricResponse[entityName][command] = eachEntity
                            
                        # Add metrics for multi-channel instances
                        # Keep track of the previous number and add it to a new metric grouped by the entity
                        # This also takes care of initialization issues of the new metric if it does not exist and adds to it if it exists
                        if command == 'MQCMD_INQUIRE_CHANNEL_STATUS':
                            if MQCACH_LAST_MSG_DATE in eachEntity:
                                lastMsgDate = datetime.strptime(eachEntity[MQCACH_LAST_MSG_DATE], '%Y-%m-%d') if eachEntity[MQCACH_LAST_MSG_DATE] != '' else None
                                lastMsgTime = datetime.strptime(eachEntity[MQCACH_LAST_MSG_TIME], '%H.%M.%S') if eachEntity[MQCACH_LAST_MSG_TIME] != '' else None
                                if isinstance(lastMsgDate, datetime) and isinstance(lastMsgTime, datetime):
                                    lastMsgDateTime = datetime.combine(lastMsgDate.date(), lastMsgTime.time())
                                    
                                    if ('lastMsg' not in metricResponse[entityName]) or ('lastMsg' in metricResponse[entityName] and metricResponse[entityName]['lastMsg'] < lastMsgDateTime):
                                        metricResponse[entityName]['lastMsg'] = lastMsgDateTime
                                        
                            # Since channels can have multiple instances of its parent, but those instances can disconnect, reset from 0, restart at any time.
                            # This causes their delta to spike up because they dropped or reset their counters.
                            # An issue can occur when a channel instance disconnects, or resets its values to 0 because the delta can spike really high
                            # if this occurs.
                            # The following block uses the jobname associated with the channel instance to keep track of them and make sure that we handle when any of them reset
                            # or disconnect so we can show their true delta from the last aggregate.
                            for metric in self.cMetrics:
                                if 'aggregationField' in metric and metric['attr'] in eachEntity:
                                    val = int(eachEntity[metric["attr"]])
                                    
                                    if metric["attr"] == MQIACH_CURRENT_SHARING_CONVS:
                                        metricResponse[entityName][MQIACH_CURRENT_SHARING_CONVS] = metricResponse[entityName][MQIACH_CURRENT_SHARING_CONVS]+val if metric["aggregationField"] in metricResponse[entityName] else val
                                    else:
                                        if qmgr_name not in self.channelMetricHolder:
                                            self.channelMetricHolder[qmgr_name] = {}
                                        if entityName not in self.channelMetricHolder[qmgr_name]:
                                            self.channelMetricHolder[qmgr_name][entityName] = {}
                                        
                                        job_name = eachEntity[MQCACH_MCA_JOB_NAME].strip()
                                        #self.logger.debug(f'Channel = {entityName}. Job = {job_name}')
                                        
                                        if job_name not in self.channelMetricHolder[qmgr_name][entityName]:
                                            self.channelMetricHolder[qmgr_name][entityName][job_name] = {}
                                        
                                        channel_instance_job = self.channelMetricHolder[qmgr_name][entityName][job_name]
                                        #self.logger.debug(f'Channel instance job={channel_instance_job}')
                                        if metric["attr"] in channel_instance_job:
                                         
                                            # Values should be increasing. If they decreased in comparison to previous one, then channel restarted
                                            # so take its current value as new messages since last poll (delta)
                                            if val < channel_instance_job[metric["attr"]]["value"]:
                                                #self.logger.debug(f'Value metric id {metric["attr"]} for job {job_name} decreased, resetting. New value = {val}')
                                                # Reset the value
                                                channel_instance_job[metric["attr"]]["delta"] = val
                                            else:
                                                # Add new value
                                                delta = abs(channel_instance_job[metric["attr"]]["value"]-val)
                                                #self.logger.debug(f'Previous value={channel_instance_job[metric["attr"]]["value"]}. Current value={val}. Delta = {delta}')
                                                channel_instance_job[metric["attr"]]["delta"] = delta
                                            channel_instance_job['ignore'] = False
                                            channel_instance_job[metric["attr"]]["value"] = val
                                        else:
                                            # We need to ignore the first count, and only use it as a starting point to compare with the next minute
                                            # otherwise we start with a huge spike if the number is high.
                                            #self.logger.debug(f'Initializing metric. Metric attr = {metric["attr"]} with value = {val}')
                                            channel_instance_job[metric["attr"]] = {"value": val}
                                            
                                            # If it's the first time we are executing the extension, we don't have a baseline of channels yet. Ignore using the current value
                                            # If it's not the first time executing the extension, then this must be a new channel connecting, use the current value and add to sum
                                            channel_instance_job['ignore'] = True if self.firstExecution == True else False
                                            if not self.firstExecution:
                                                channel_instance_job[metric["attr"]]["delta"] = val
                                        
                        #if command == 'MQCMD_INQUIRE_Q':
                        #    qType[entity] = eachEntity[MQIA_Q_TYPE]
                        #self.logger.debug(f'Did command {command} for entity {entity}[{i}]. Size: {len(eachEntity)}')
                        currentIteration += 1
                        
                        # If the current iteration from any entity reached max MAX_RESULTS, stop and return
                        # This is to avoid bringing back too many when using wildcards
                        if currentIteration == MAX_RESULTS:
                            break
                        
                    # Remove channel instances from memory that no longer exist because the job attached to the instance finished or was removed
                    if command == 'MQCMD_INQUIRE_CHANNEL_STATUS':
                        #self.logger.debug(f'Full INQUIRE CHANNEL STATUS response = {fullResponse}')
                        
                        job_list = [str(each_entity[MQCACH_MCA_JOB_NAME].strip(),'utf-8', 'ignore') for each_entity in fullResponse]
                        self.channelMetricHolder[qmgr_name][entityName] ={k:v for (k,v) in self.channelMetricHolder[qmgr_name][entityName].items() if k in job_list}
                        
                        # Add all with true delta
                        aggregator = {}
                        for job in self.channelMetricHolder[qmgr_name][entityName]:
                            #self.logger.info(f'Doing job {job} in entity {entityName}')
                            for metric_id in self.channelMetricHolder[qmgr_name][entityName][job]:
                                if metric_id != 'ignore' and self.channelMetricHolder[qmgr_name][entityName][job]['ignore'] == False:
                                    
                                    if metric_id not in aggregator:
                                        aggregator[metric_id] = 0
                                    
                                    #self.logger.debug(f'EntityName = {entityName}. Metric ID = {metric_id}. Adding value {self.channelMetricHolder[qmgr_name][entityName][job][metric_id]["delta"]} to {aggregator[metric_id]}')
                                    aggregator[metric_id] += self.channelMetricHolder[qmgr_name][entityName][job][metric_id]["delta"]
                        
                        for metric_id in aggregator:
                            #self.logger.debug(f'Final - {entityName}[{metric_id}] = {aggregator[metric_id]}')
                            metricResponse[entityName][metric_id] = aggregator[metric_id]
                            
                except pymqi.MQMIError as e:
                    if e.comp == MQCC_WARNING and e.reason == MQRC_SELECTOR_NOT_FOR_TYPE:
                        self.logger.warn(f'{command} command not supported on this OS. Continuing...')
                    elif e.comp == MQCC_FAILED and e.reason == MQRCCF_CHL_STATUS_NOT_FOUND:
                        if entity not in metricResponse:
                            metricResponse[entity] = {}
                        if command not in metricResponse[entity]:
                            metricResponse[entity][command] = {}
                        metricResponse[entity][command][MQIACH_CHANNEL_STATUS] = 'INACTIVE'
                    elif e.comp == MQCC_FAILED and e.reason == MQRC_UNKNOWN_OBJECT_NAME:
                        self.report_custom_info_event(f'Error collecting information for {entity} on {qmgr_name}, not found. {e.errorAsString()}', f'{entity} on {qmgr_name}, not found', {}, pgi)
                        self.logger.warn(f'Error collecting information for {entity} on {qmgr_name}. {e.errorAsString()}')
                    else:
                        self.logger.error(f'Error occurred collecting data for {entity} on {qmgr_name}. {e.errorAsString()}')
                    continue
        #self.logger.info('------ Response: ' + str(metricResponse) + ' for entities ' + str(entities) + ' using command ' + str(commands))
    
    def makeConnection(self, qmgr_name):
        try:
            if self.user == '' and self.password == '':
                qmgr = pymqi.connect(qmgr_name.strip())
            else:
                qmgr = pymqi.QueueManager(None)
                qmgr.connect_with_options(qmgr_name.strip(), user=self.user, password=self.password)
            return qmgr
        except pymqi.MQMIError as e:
            self.logger.warn(f'Could not connect to {qmgr_name}: {e.errorAsString()}. Skipping')
            return None
        
    # Set metric according to metric type: absolute or relative            
    def setMetric(self, qmgr_name, metricType, keyName, val, metricDimension, pgi):
        #self.logger.info(f'Setting metric for process running on port {self.port}')
        self.logger.debug(f'Setting metric for {qmgr_name}')
        if (metricType == 'absolute'):
            self.results_builder.absolute(key=keyName, value=val, dimensions=metricDimension, entity_selector=pgi)
        else:
            key = qmgr_name+'_'+list(metricDimension.values())[0]+'_'+keyName
            if key not in self.metricHolder:
                self.metricHolder[key] = val
            else:
                deltaVal = abs(self.metricHolder[key]-val)
                self.metricHolder[key] = val
                #self.logger.info(f'Setting Delta: {deltaVal} for dimension: {metricDimension}')
                self.results_builder.absolute(key=keyName, value=deltaVal, dimensions=metricDimension, entity_selector=pgi)
            
    def report_custom_info_event(self, message, title, properties={}, pgi=None):
        if self.events < MAX_EVENTS:
            if title + message not in self.previousEvents:
                self.events += 1
                self.results_builder.report_custom_info_event(message, title, properties=properties, entity_selector=pgi)
                self.previousEvents.append(title + message)
                
    def build_topology(self, pcf, qmgr_conn, qmgr_name, pgi):
        cluster_data = {}
        clusterNameList, qNameList = None, None
        jsonified = None
        nameListResponse = None
        
        cluster_data['name'] = qmgr_name
        cluster_data['clusters'] = []
        self.logger.debug('Inquiring cluster names')
        
        try: 
            # Get non-repository clusters
            args = {pymqi.CMQC.MQCA_CLUSTER_Q_MGR_NAME : pymqi.ensure_bytes(qmgr_name), 
                    MQIACF_CLUSTER_Q_MGR_ATTRS: pymqi.CMQC.MQCA_CLUSTER_NAME}
            clusterResponse = pcf.MQCMD_INQUIRE_CLUSTER_Q_MGR(args)
            #self.logger.info(f'ClusterResponse: {clusterResponse}')
            for each in clusterResponse:
                if MQCA_CLUSTER_NAME in each:
                    if isinstance(each[MQCA_CLUSTER_NAME],list):
                        for x in each[MQCA_CLUSTER_NAME]:
                            cluster_data['clusters'].append(x.strip())
                    else:
                        cluster_data['clusters'].append(each[MQCA_CLUSTER_NAME].strip())
        except pymqi.MQMIError as e:
            if e.reason != MQRC_UNKNOWN_OBJECT_NAME:                                        
                self.logger.error(f'Could not inquire cluster names from queue manager {qmgr_name}. {e.errorAsString()}')
                self.report_custom_info_event(f'Could not get cluster names from queue manager {qmgr_name}.', 'Error collecting topology from MQ', {'Queue manager': qmgr_name, 'Error': e.errorAsString()}, pgi)
                
        # Get repository clusters
        cluster = str(qmgr_conn.inquire(MQCA_REPOSITORY_NAME), 'utf-8', 'ignore').strip()
        clusterNameList = str(qmgr_conn.inquire(MQCA_REPOSITORY_NAMELIST), 'utf-8', 'ignore').strip()

        if clusterNameList != '' and not clusterNameList.strip().startswith('SYSTEM.'):
            self.logger.debug(f'Getting clusters for namelist: {clusterNameList}')
            #args = {pymqi.CMQC.MQCA_NAMELIST_NAME : b'*'}
            args = {pymqi.CMQC.MQCA_NAMELIST_NAME : pymqi.ensure_bytes(clusterNameList)}
            try:
                nameListResponse = pcf.MQCMD_INQUIRE_NAMELIST(args)
                self.logger.debug(f'nameListResponse = {nameListResponse}')                                                                                                                                                                       
                for each in nameListResponse:
                    #cluster_data['clusters'] = [x.strip() for x in nameListResponse[0][MQCA_NAMES]]
                    if MQCA_NAMES in each:
                        if isinstance(each[MQCA_NAMES], list):
                            for x in each[MQCA_NAMES]:
                                cluster_data['clusters'].append(x.strip())
                        else:
                            cluster_data['clusters'].append(each[MQCA_NAMES].strip())
            except pymqi.MQMIError as e:
                if e.reason == MQRC_UNKNOWN_OBJECT_NAME:
                    self.logger.warn('No result for namelists. No namelists to collect. Skipping...')
                else:
                    self.logger.error(f'Error getting clusters in namelist {clusterNameList} for {qmgr_name}. {e.errorAsString()}')
                    self.report_custom_info_event(f'Could not get clusters for namelist {str(clusterNameList, "utf-8", "ignore")} in {qmgr_name}.', 'Error getting clusters from MQ', {'Queue manager': qmgr_name, 'Error': e.errorAsString()}, pgi)
            
            # In case there are duplicates
            self.logger.debug(f"Added clusters from namelist: {list( dict.fromkeys(cluster_data['clusters']) )}")
            cluster_data['clusters'] = list( dict.fromkeys(cluster_data['clusters']) )
        elif cluster != '' and not cluster.strip().startswith('SYSTEM.'):
            cluster_data['clusters'].append(cluster)
            
        # Retrieve Alias Queue information
        self.logger.debug('Getting alias queues')
        cluster_data['aliasQueues'] = []
        try:
            args = {pymqi.CMQC.MQCA_Q_NAME : b'*',
                    pymqi.CMQC.MQIA_Q_TYPE : pymqi.CMQC.MQQT_ALIAS}
                    
            aliasQResponse = pcf.MQCMD_INQUIRE_Q(args)

            for aliasQ in aliasQResponse:
                if not aliasQ[MQCA_Q_NAME].startswith(b'SYSTEM.') and not aliasQ[MQCA_Q_NAME].startswith(b'MQSERIES.TEMPLATE.'):
                    if not aliasQ[MQCA_Q_NAME].strip() == b'' and not aliasQ[MQCA_BASE_Q_NAME].strip() == b'':
                        cluster = aliasQ[MQCA_CLUSTER_NAME].strip()
                        clusterNameList = aliasQ[MQCA_CLUSTER_NAMELIST].strip()
                        aliasQClusters = []
                        if cluster != b'':
                            aliasQClusters = [cluster]
                        elif clusterNameList != b'':
                            self.logger.debug(f'Getting cluster names for namelist {clusterNameList} from aliasQueue {aliasQ[MQCA_Q_NAME]}')
                            args = {pymqi.CMQC.MQCA_NAMELIST_NAME : pymqi.ensure_bytes(clusterNameList)}
                            try:
                                nameListResponse = pcf.MQCMD_INQUIRE_NAMELIST(args)
                                #aliasQClusters = [x.strip() for x in nameListResponse[0][MQCA_NAMES]]
                                self.logger.debug(f'nameListResponse in aliasQueue: {nameListResponse}')
                                for each in nameListResponse:
                                    if MQCA_NAMES in each:
                                        if isinstance(each[MQCA_NAMES], list):
                                            for x in each[MQCA_NAMES]:
                                                aliasQClusters.append(x.strip())
                                        else:
                                            aliasQClusters.append(each[MQCA_NAMES].strip())
                            except pymqi.MQMIError as e:
                                if e.reason == MQRC_UNKNOWN_OBJECT_NAME:
                                    self.logger.warn(f'{qmgr_name}: No result for alias queues clusters in namelist. No alias queues clusters to collect. Skipping...')
                                else:
                                    self.logger.error(f'Error getting aliasQ clusters in namelist {str(clusterNameList, "utf-8", "ignore")} for {qmgr_name}. {e.errorAsString()}')
                                    self.report_custom_info_event(f'Could not get clusters for namelist {str(clusterNameList, "utf-8", "ignore")} in {qmgr_name}.', 'Error getting clusters from MQ', {'Queue manager': qmgr_name, 'Error': e.errorAsString()}, pgi)
                            # In case there are duplicates
                            aliasQClusters = list( dict.fromkeys(aliasQClusters) )
                        if aliasQ[MQCA_Q_NAME].strip().upper() != aliasQ[MQCA_BASE_Q_NAME].strip().upper():
                            cluster_data['aliasQueues'].append({'aliasQueue': aliasQ[MQCA_Q_NAME].strip(), 'baseQueue': aliasQ[MQCA_BASE_Q_NAME].strip(), 'clusterVisibility': aliasQClusters})
        except pymqi.MQMIError as e:
            if e.reason == MQRC_UNKNOWN_OBJECT_NAME:
                self.logger.warn(f'{qmgr_name}: No result for alias queues. No alias queues to collect. Skipping...')
            else:
                self.logger.error(f'Error getting alias queues for {qmgr_name}. {e.errorAsString()}')
                self.report_custom_info_event(f'Could not get alias queues in {qmgr_name}.', 'Error getting alias queues from MQ', {'Queue manager': qmgr_name, 'Error': e.errorAsString()}, pgi)
        
        # Retrieve Remote queue information
        self.logger.debug('Getting remote queues')
        cluster_data['remoteQueues'] = []
        try:
            args = {pymqi.CMQC.MQCA_Q_NAME : b'*',
                    pymqi.CMQC.MQIA_Q_TYPE : pymqi.CMQC.MQQT_REMOTE}
                    
            remoteQResponse = pcf.MQCMD_INQUIRE_Q(args)

            for remoteQ in remoteQResponse:
                if not remoteQ[MQCA_Q_NAME].startswith(b'SYSTEM.') and not remoteQ[MQCA_Q_NAME].startswith(b'MQSERIES.TEMPLATE.'):
                    if not remoteQ[MQCA_Q_NAME].strip() == b'' and not remoteQ[MQCA_REMOTE_Q_NAME].strip() == b'' and not remoteQ[MQCA_REMOTE_Q_MGR_NAME].strip() == b'':
                        cluster = remoteQ[MQCA_CLUSTER_NAME].strip()
                        clusterNameList = remoteQ[MQCA_CLUSTER_NAMELIST].strip()
                        remoteQClusters = []
                        if cluster != b'':
                            remoteQClusters = [cluster]
                        elif clusterNameList != b'':
                            self.logger.debug(f'Getting clusters for namelist: {clusterNameList} from remoteQueue {remoteQ[MQCA_Q_NAME]}')
                            args = {pymqi.CMQC.MQCA_NAMELIST_NAME : pymqi.ensure_bytes(clusterNameList)}
                            
                            try:
                                nameListResponse = pcf.MQCMD_INQUIRE_NAMELIST(args)
                                #remoteQClusters = [x.strip() for x in nameListResponse[0][MQCA_NAMES]]
                                self.logger.debug(f'nameListResponse in remoteQueue: {nameListResponse}')                                                                                                                                                                                                                 
                                for each in nameListResponse:
                                    if MQCA_NAMES in each:
                                        if isinstance(each[MQCA_NAMES], list):
                                            for x in each[MQCA_NAMES]:
                                                remoteQClusters.append(x.strip())
                                        else:
                                            remoteQClusters.append(each[MQCA_NAMES].strip())
                            except pymqi.MQMIError as e:
                                if e.reason == MQRC_UNKNOWN_OBJECT_NAME:
                                    self.logger.warn(f'{qmgr_name}: No result for remote queues clusters in namelists. No clusters in namelist to collect. Skipping...')
                                else:
                                    self.logger.error(f'Error getting remoteQ clusters in namelist {clusterNameList} for {qmgr_name}. {e.errorAsString()}')
                                    self.report_custom_info_event(f'Could not get clusters for namelist {str(clusterNameList, "utf-8", "ignore")} in {qmgr_name}.', 'Error getting clusters from MQ', {'Queue manager': qmgr_name, 'Error': e.errorAsString()}, pgi)
                            
                            # In case there are duplicates
                            remoteQClusters = list( dict.fromkeys(remoteQClusters) )
                        cluster_data['remoteQueues'].append({'localQueue': remoteQ[MQCA_Q_NAME].strip(), 'remoteQueue': remoteQ[MQCA_REMOTE_Q_NAME].strip(), 'remoteQueueManager': remoteQ[MQCA_REMOTE_Q_MGR_NAME].strip(), 'clusterVisibility': remoteQClusters})
        except pymqi.MQMIError as e:
            if e.reason == MQRC_UNKNOWN_OBJECT_NAME:
                self.logger.warn(f'{qmgr_name}: No result for remote queues. No remote queues to collect. Skipping...')
            else:
                self.logger.error(f'Error getting remote queues for {qmgr_name}. {e.errorAsString()}')
                self.report_custom_info_event(f'Could not get remote queues in {qmgr_name}.', 'Error getting remote queues from MQ', {'Queue manager': qmgr_name, 'Error': e.errorAsString()}, pgi)
        
        # Retrieve Cluster queue information
        self.logger.debug('Getting cluster queue information')
        cluster_data['clusterQueues'] = []
        args = {pymqi.CMQC.MQCA_Q_NAME : b'*',
                pymqi.CMQC.MQIA_Q_TYPE : pymqi.CMQC.MQQT_CLUSTER}
                
        try:
            clusterQResponse = pcf.MQCMD_INQUIRE_Q(args)
            for clusterQ in clusterQResponse:
                cluster = clusterQ[MQCA_CLUSTER_NAME].strip()
                if not (clusterQ[MQCA_Q_NAME].strip() in [queue['aliasQueue'] for queue in cluster_data['aliasQueues']]) and not (clusterQ[MQCA_Q_NAME].strip() in [queue['localQueue'] for queue in cluster_data['remoteQueues']]) and not (clusterQ[MQCA_Q_NAME].strip() in [queue['localQueue'] for queue in cluster_data['clusterQueues']]):
                    if not clusterQ[MQCA_Q_NAME].strip() == '':
                        cluster_data['clusterQueues'].append({'localQueue': clusterQ[MQCA_Q_NAME].strip(), 'clusterVisibility': [cluster]})
        except pymqi.MQMIError as e:
            if e.reason == MQRC_UNKNOWN_OBJECT_NAME:
                self.logger.info(f'{qmgr_name}: Inquired cluster information, got no result. No cluster information to collect. Skipping...')
            else:
                self.logger.error(f'Error getting cluster information for {qmgr_name}. {e.errorAsString()}')
                self.report_custom_info_event(f'Could not get cluster queues for {qmgr_name}.', 'Error getting cluster data from MQ', {'Queue manager': qmgr_name, 'Error': e.errorAsString()}, pgi)

        jsonified = json.dumps( cluster_data, cls=EncodeText )
        
        return jsonified
        
    def send_topology(self,data,apiToken,endpoint, qmgr_name, pgi):
        try:
            if not endpoint.endswith('/'):
                endpoint += '/'
            if not endpoint.startswith('http'):
                endpoint = 'https://'+endpoint
                
            url = f'{endpoint}api/config/v1/service/ibmMQTracing/queueManager/{qmgr_name}'
            
            # Put the data
            response = requests.put(f'{url}', proxies=self.request_proxy_list, data=data, headers={'Content-Type': 'application/json', 'Authorization': f'Api-Token {apiToken}'}, verify=False, timeout=10)
            
            if response.status_code == 204 or response.status_code == 201:
                self.logger.info('Succeeded sending topology')
                self.last_topology_retrieve[qmgr_name]['time'] = time.time()
                return True
            else:
                self.logger.error(f'Error sending topology to API {url}. Response code: {response.status_code}. {response.text}. Data: {data}')
                self.results_builder.report_error_event(f'An error occurred sending queue manager {qmgr_name} topology mapping to environment', 'Error sending MQ topology', {'Queue manager': qmgr_name, 'Error code': response.status_code, 'Response': response.text}, entity_selector=pgi)
                return False
        except Exception as e:
            self.logger.error(f'Failed to communicate with endpoint {url}. {e}')
            self.results_builder.report_error_event(f'An error occurred sending queue manager {qmgr_name} topology mapping to environment. Check plugin log for further error details.', 'Error sending MQ topology', {'Queue manager': qmgr_name}, entity_selector=pgi)
            return False

    def add_property(self, key: str, value: str, pgi):
        prop = PluginProperty(key=key, value=value, me_attribute=MEAttribute.CUSTOM_PG_METADATA, entity_selector=pgi)
        self.results_builder.add_property(prop)